use dsi_bitstream::prelude::{
    BitReader, BitSeek, BitWrite, BufBitWriter, LE, MemWordReader, MemWordWriterVec, ZetaRead,
    ZetaWrite,
};
use postcard;
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicUsize, Ordering};
use tantivy_bitpacker::{BitPacker, BitUnpacker};
use toolkit::elias_fano::EliasFano;
use toolkit::stream_vbyte::StreamVByteBlocks;

/// Stores raw neighbor data and offsets
#[derive(Clone)]
pub struct NeighborData {
    pub data: Box<[u32]>,      // neighbor IDs
    pub offsets: Box<[usize]>, // segment offsets
}

/// Trait for neighbor arrays (plain or compressed)
pub trait Neighbors {
    type Iter<'a>: Iterator<Item = u32> + 'a
    where
        Self: 'a;

    fn len(&self) -> usize;
    fn n_nodes(&self) -> usize;

    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a>;

    fn byte_size(&self) -> usize;
}

/// Plain neighbors stored as Box<[u32]>
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct PlainNeighbors {
    data: Box<[u32]>,
    offsets: Box<[usize]>,
}

impl From<NeighborData> for PlainNeighbors {
    fn from(nd: NeighborData) -> Self {
        PlainNeighbors {
            data: nd.data,
            offsets: nd.offsets,
        }
    }
}

pub struct PlainNeighborsIter<'a> {
    slice: std::slice::Iter<'a, u32>,
}

impl<'a> Iterator for PlainNeighborsIter<'a> {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<u32> {
        self.slice.next().copied()
    }
}

impl Neighbors for PlainNeighbors {
    type Iter<'a> = PlainNeighborsIter<'a>;

    fn len(&self) -> usize {
        self.data.len()
    }

    fn n_nodes(&self) -> usize {
        self.offsets.len().saturating_sub(1)
    }

    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a> {
        let start = self.offsets[node_id];
        let end = self.offsets[node_id + 1];
        PlainNeighborsIter {
            slice: self.data[start..end].iter(),
        }
    }

    fn byte_size(&self) -> usize {
        self.data.len() * std::mem::size_of::<u32>()
            + self.offsets.len() * std::mem::size_of::<usize>()
    }
}


/// Elias-Fano encoded offsets (compressed variable-length encoding)
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct EliasFanoOffsets {
    ef: EliasFano, // Elias-Fano structure
}

impl From<Box<[usize]>> for EliasFanoOffsets {
    fn from(data: Box<[usize]>) -> Self {
        Self::from_slice(&data)
    }
}

impl EliasFanoOffsets {
    pub fn from_slice(offsets: &[usize]) -> Self {
        let mut vec = Vec::with_capacity(offsets.len());
        for (i, &v) in offsets.iter().enumerate() {
            vec.push(v + i);
        }
        EliasFanoOffsets { ef: EliasFano::from(&vec) }
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.ef.len()
    }

    #[inline]
    pub fn get(&self, i: usize) -> usize {
        self.ef.select(i).unwrap() - i
    }

    #[inline]
    pub fn try_get(&self, i: usize) -> Option<usize> {
        self.ef.select(i).map(|v| v - i)
    }

    pub fn byte_size(&self) -> usize {
        postcard::to_allocvec(&self.ef).unwrap().len()
    }
}

/// Bit-packed neighbors (compressed with fixed bit width)
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct BitPackedNeighbors {
    data: Box<[u8]>,    // packed data
    offsets: EliasFanoOffsets,
    bit_width: u8,      // bits per value
    logical_len: usize, // number of values
}

pub struct BitPackedIter<'a> {
    data: &'a [u8],
    unpacker: BitUnpacker,
    pos: usize,
    end: usize,
}

impl<'a> Iterator for BitPackedIter<'a> {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<u32> {
        if self.pos >= self.end {
            return None;
        }
        let val = self.unpacker.get(self.pos as u32, self.data) as u32;
        self.pos += 1;
        Some(val)
    }
}

impl BitPackedNeighbors {
    /// Compress plain neighbors using bit-packing
    pub fn compress(data: &[u32], offsets: Box<[usize]>, bit_width: u8) -> Self {
        let mut packed = Vec::new();
        let mut packer = BitPacker::new();

        for &val in data.iter() {
            packer.write(val as u64, bit_width, &mut packed).unwrap();
        }
        packer.close(&mut packed).unwrap();

        BitPackedNeighbors {
            data: packed.into_boxed_slice(),
            offsets: EliasFanoOffsets::from(offsets),
            bit_width,
            logical_len: data.len(),
        }
    }
}

impl From<NeighborData> for BitPackedNeighbors {
    fn from(nd: NeighborData) -> Self {
        // choose minimal bit width based on max ID
        let max_id = nd.data.iter().copied().max().unwrap_or(0);
        let bit_width = (32 - (max_id as u32).leading_zeros()) as u8;
        let bit_width = bit_width.max(1);

        BitPackedNeighbors::compress(&nd.data, nd.offsets, bit_width)
    }
}

impl Neighbors for BitPackedNeighbors {
    type Iter<'a> = BitPackedIter<'a>;

    #[inline]
    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a> {
        let start = self.offsets.get(node_id);
        let end = self.offsets.get(node_id + 1);
        BitPackedIter {
            data: &self.data,
            unpacker: BitUnpacker::new(self.bit_width),
            pos: start,
            end,
        }
    }

    fn len(&self) -> usize {
        self.logical_len
    }

    fn n_nodes(&self) -> usize {
        self.offsets.len().saturating_sub(1)
    }

    fn byte_size(&self) -> usize {
        self.data.len() + self.offsets.byte_size()
    }
}

/// Elias-Fano encoded neighbors (compressed variable-length encoding)
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct EliasFanoNeighbors {
    ef: EliasFano,      // Elias-Fano structure
    offsets: EliasFanoOffsets,
    logical_len: usize, // number of values
}

pub struct EliasFanoIter<'a> {
    ef: &'a EliasFano,
    pos: usize,
    end: usize,
    base: usize,
}

impl<'a> Iterator for EliasFanoIter<'a> {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.pos >= self.end {
            return None;
        }

        let encoded = self.ef.select(self.pos)?;
        self.pos += 1;

        if encoded < self.base + 1 {
            return None;
        }

        let decoded = encoded - (self.base + 1);

        Some(decoded as u32)
    }
}

impl Neighbors for EliasFanoNeighbors {
    type Iter<'a> = EliasFanoIter<'a>;

    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a> {
        let start = self.offsets.get(node_id);
        let end = self.offsets.get(node_id + 1);
        let base = if start == 0 {
            0
        } else {
            self.ef.select(start - 1).unwrap_or(0)
        };

        EliasFanoIter {
            ef: &self.ef,
            pos: start,
            end: end.min(self.logical_len),
            base,
        }
    }

    fn len(&self) -> usize {
        self.logical_len
    }

    fn n_nodes(&self) -> usize {
        self.offsets.len().saturating_sub(1)
    }

    fn byte_size(&self) -> usize {
        postcard::to_allocvec(&self.ef).unwrap().len() + self.offsets.byte_size()
    }
}

impl From<NeighborData> for EliasFanoNeighbors {
    fn from(nd: NeighborData) -> Self {
        let mut list = Vec::new();
        let mut last_id = 0;

        // encode neighbors segment by segment
        for seg in nd.offsets.windows(2) {
            let start = seg[0];
            let end = seg[1];

            let mut segment: Vec<usize> = nd.data[start..end].iter().map(|&x| x as usize).collect();

            if !segment.is_empty() {
                // ensure strictly increasing global sequence
                for id in &mut segment {
                    *id += last_id + 1;
                }
                last_id = *segment.last().unwrap();
                list.extend(segment);
            }
        }

        let ef = EliasFano::from(&list);
        let ef_len = ef.len();
        let offsets = EliasFanoOffsets::from(nd.offsets);
        EliasFanoNeighbors {
            ef,
            offsets,
            logical_len: ef_len,
        }
    }
}

/// Residual-only Zeta-coded neighbors inspired by WebGraph.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZetaNeighbors {
    data: Box<[u64]>,
    bit_offsets: EliasFanoOffsets,
    flat_offsets: EliasFanoOffsets,
    logical_len: usize,
    #[serde(default = "default_zeta_codec_k")]
    codec_k: usize,
}

const DEFAULT_ZETA_CODEC_K: usize = 3;
static ZETA_CODEC_K: AtomicUsize = AtomicUsize::new(DEFAULT_ZETA_CODEC_K);

pub fn set_zeta_codec_k(codec_k: usize) {
    assert!(codec_k > 0, "zeta codec k must be greater than 0");
    ZETA_CODEC_K.store(codec_k, Ordering::Relaxed);
}

pub fn zeta_codec_k() -> usize {
    ZETA_CODEC_K.load(Ordering::Relaxed)
}

fn default_zeta_codec_k() -> usize {
    DEFAULT_ZETA_CODEC_K
}

impl From<NeighborData> for ZetaNeighbors {
    fn from(nd: NeighborData) -> Self {
        ZetaNeighbors::compress(&nd)
    }
}

impl Default for ZetaNeighbors {
    fn default() -> Self {
        ZetaNeighbors {
            data: Box::new([]),
            bit_offsets: EliasFanoOffsets::from_slice(&[0]),
            flat_offsets: EliasFanoOffsets::from_slice(&[0]),
            logical_len: 0,
            codec_k: default_zeta_codec_k(),
        }
    }
}

pub struct ZetaIter<'a> {
    reader: BitReader<LE, MemWordReader<u64, &'a [u64]>>,
    remaining: usize,
    next_value: u32,
    codec_k: usize,
}

impl<'a> Iterator for ZetaIter<'a> {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.remaining == 0 {
            return None;
        }

        let value = self.next_value;
        self.remaining -= 1;

        if self.remaining != 0 {
            let gap = self.reader.read_zeta(self.codec_k).unwrap() as u32;
            self.next_value = value + 1 + gap;
        }

        Some(value)
    }
}

impl Neighbors for ZetaNeighbors {
    type Iter<'a> = ZetaIter<'a>;

    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a> {
        let Some(start) = self.flat_offset(node_id) else {
            return Self::empty_iter();
        };
        let Some(end) = self.flat_offset(node_id + 1) else {
            return Self::empty_iter();
        };
        self.iter_from_node(node_id, start, end)
    }

    fn len(&self) -> usize {
        self.logical_len
    }

    fn n_nodes(&self) -> usize {
        self.flat_offsets.len().saturating_sub(1)
    }

    fn byte_size(&self) -> usize {
        self.data.len() * std::mem::size_of::<u64>()
            + self.bit_offsets.byte_size()
            + self.flat_offsets.byte_size()
    }
}

impl ZetaNeighbors {
    fn compress(plain: &NeighborData) -> Self {
        Self::compress_with_k(plain, zeta_codec_k())
    }

    pub fn compress_with_k(plain: &NeighborData, codec_k: usize) -> Self {
        assert!(codec_k > 0, "zeta codec k must be greater than 0");

        let mut words = Vec::<u64>::new();
        let mut writer = BufBitWriter::<LE, _>::new(MemWordWriterVec::new(&mut words));
        let num_segments = plain.offsets.len().saturating_sub(1);
        let mut bit_offsets = Vec::with_capacity(num_segments + 1);
        let mut flat_offsets = Vec::with_capacity(num_segments + 1);
        let mut bit_pos = 0usize;

        bit_offsets.push(0);
        flat_offsets.push(0);

        for node_id in 0..num_segments {
            let start = plain.offsets[node_id];
            let end = plain.offsets[node_id + 1];
            bit_pos +=
                write_zeta_segment(&mut writer, node_id, &plain.data[start..end], codec_k);
            bit_offsets.push(bit_pos);
            flat_offsets.push(end);
        }

        writer.flush().unwrap();
        drop(writer);

        ZetaNeighbors {
            data: words.into_boxed_slice(),
            bit_offsets: EliasFanoOffsets::from_slice(&bit_offsets),
            flat_offsets: EliasFanoOffsets::from_slice(&flat_offsets),
            logical_len: plain.data.len(),
            codec_k,
        }
    }

    fn iter_from_node<'a>(&'a self, node_id: usize, start: usize, end: usize) -> ZetaIter<'a> {
        if start >= end || self.logical_len == 0 {
            return Self::empty_iter();
        }

        debug_assert_eq!(self.flat_offset(node_id), Some(start));
        debug_assert_eq!(self.flat_offset(node_id + 1), Some(end));

        let mut reader = BitReader::<LE, _>::new(MemWordReader::new(&self.data[..]));
        let Some(bit_pos) = self.bit_offset(node_id) else {
            return Self::empty_iter();
        };
        reader.set_bit_pos(bit_pos).unwrap();

        Self::build_iter(reader, node_id, end - start, self.codec_k)
    }

    fn build_iter<'a>(
        mut reader: BitReader<LE, MemWordReader<u64, &'a [u64]>>,
        node_id: usize,
        degree: usize,
        codec_k: usize,
    ) -> ZetaIter<'a> {
        if degree == 0 {
            return Self::empty_iter();
        }

        let first = reader.read_zeta(codec_k).unwrap();
        let first_value = node_id as i64 + nat_to_i64(first);
        debug_assert!(first_value >= 0);

        ZetaIter {
            reader,
            remaining: degree,
            next_value: first_value as u32,
            codec_k,
        }
    }

    fn empty_iter<'a>() -> ZetaIter<'a> {
        ZetaIter {
            reader: BitReader::<LE, _>::new(MemWordReader::new(&[])),
            remaining: 0,
            next_value: 0,
            codec_k: default_zeta_codec_k(),
        }
    }

    #[inline]
    fn bit_offset(&self, node_id: usize) -> Option<u64> {
        self.bit_offsets.try_get(node_id).map(|v| v as u64)
    }

    #[inline]
    fn flat_offset(&self, node_id: usize) -> Option<usize> {
        self.flat_offsets.try_get(node_id)
    }
}

/// Stream VByte compressed independently per adjacency list.
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct StreamVByteNeighbors {
    blocks: StreamVByteBlocks<u32>,
    empty_nodes: Box<[u64]>,
    logical_len: usize,
}

const STREAMVBYTE_BLOCKS_SMALL_BUF: usize = 64;
const STREAMVBYTE_BLOCKS_MAX_BUF: usize = 256;

pub enum StreamVByteIter {
    Empty,
    Small {
        buf: [u32; STREAMVBYTE_BLOCKS_SMALL_BUF],
        pos: usize,
        len: usize,
        acc: u32,
    },
    Large {
        buf: [u32; STREAMVBYTE_BLOCKS_MAX_BUF],
        pos: usize,
        len: usize,
        acc: u32,
    },
}

impl StreamVByteIter {
    #[inline]
    fn empty() -> Self {
        Self::Empty
    }

    #[inline]
    fn small() -> Self {
        Self::Small {
            buf: [0; STREAMVBYTE_BLOCKS_SMALL_BUF],
            pos: 0,
            len: 0,
            acc: 0,
        }
    }

    #[inline]
    fn large() -> Self {
        Self::Large {
            buf: [0; STREAMVBYTE_BLOCKS_MAX_BUF],
            pos: 0,
            len: 0,
            acc: 0,
        }
    }
}

impl Iterator for StreamVByteIter {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        match self {
            StreamVByteIter::Empty => None,
            StreamVByteIter::Small { buf, pos, len, acc } => {
                if *pos >= *len {
                    return None;
                }

                *acc = acc.wrapping_add(buf[*pos]);
                *pos += 1;
                Some(*acc)
            }
            StreamVByteIter::Large { buf, pos, len, acc } => {
                if *pos >= *len {
                    return None;
                }

                *acc = acc.wrapping_add(buf[*pos]);
                *pos += 1;
                Some(*acc)
            }
        }
    }
}

impl From<NeighborData> for StreamVByteNeighbors {
    fn from(nd: NeighborData) -> Self {
        let mut deltas = Vec::with_capacity(nd.data.len().max(nd.offsets.len().saturating_sub(1)));
        let mut offsets = Vec::with_capacity(nd.offsets.len());
        let n_nodes = nd.offsets.len().saturating_sub(1);
        let mut empty_nodes = vec![0u64; n_nodes.div_ceil(64)];
        let mut has_empty_nodes = false;

        offsets.push(0);
        for node_id in 0..n_nodes {
            let start = nd.offsets[node_id];
            let end = nd.offsets[node_id + 1];
            if start == end {
                has_empty_nodes = true;
                empty_nodes[node_id / 64] |= 1u64 << (node_id % 64);
                deltas.push(0);
                offsets.push(deltas.len());
                continue;
            }

            assert!(
                end - start <= 256,
                "StreamVByteBlocks supports adjacency lists up to 256 neighbors"
            );

            let mut prev = 0u32;
            for &value in &nd.data[start..end] {
                debug_assert!(value >= prev, "Neighbor list must be sorted in ascending order");
                deltas.push(value - prev);
                prev = value;
            }
            offsets.push(deltas.len());
        }

        StreamVByteNeighbors {
            blocks: StreamVByteBlocks::new(&deltas, &offsets),
            empty_nodes: if has_empty_nodes {
                empty_nodes.into_boxed_slice()
            } else {
                Box::new([])
            },
            logical_len: nd.data.len(),
        }
    }
}

impl StreamVByteNeighbors {
    #[inline]
    fn is_empty_node(&self, node_id: usize) -> bool {
        !self.empty_nodes.is_empty()
            && self
                .empty_nodes
                .get(node_id / 64)
                .is_some_and(|word| (word & (1u64 << (node_id % 64))) != 0)
    }
}

impl Neighbors for StreamVByteNeighbors {
    type Iter<'a> = StreamVByteIter;

    fn len(&self) -> usize {
        self.logical_len
    }

    fn n_nodes(&self) -> usize {
        self.blocks.num_blocks()
    }

    fn iter_node<'a>(&'a self, node_id: usize) -> Self::Iter<'a> {
        if self.is_empty_node(node_id) {
            return StreamVByteIter::empty();
        }

        if self.blocks.block_len(node_id) <= STREAMVBYTE_BLOCKS_SMALL_BUF {
            let mut iter = StreamVByteIter::small();
            if let StreamVByteIter::Small { buf, len, .. } = &mut iter {
                *len = self.blocks.get_block(node_id, buf);
            }
            iter
        } else {
            let mut iter = StreamVByteIter::large();
            if let StreamVByteIter::Large { buf, len, .. } = &mut iter {
                *len = self.blocks.get_block(node_id, buf);
            }
            iter
        }
    }

    fn byte_size(&self) -> usize {
        postcard::to_allocvec(&self.blocks).unwrap().len()
            + self.empty_nodes.len() * std::mem::size_of::<u64>()
    }
}

fn write_zeta_segment(
    writer: &mut impl ZetaWrite<LE>,
    node_id: usize,
    neighbors: &[u32],
    codec_k: usize,
) -> usize {
    if neighbors.is_empty() {
        return 0;
    }

    let first_delta = neighbors[0] as i64 - node_id as i64;
    let mut written_bits = writer
        .write_zeta(i64_to_nat(first_delta), codec_k)
        .unwrap();

    let mut prev = neighbors[0];
    for &value in &neighbors[1..] {
        debug_assert!(value >= prev, "Neighbor list must be sorted in ascending order");
        written_bits += writer
            .write_zeta((value - prev - 1) as u64, codec_k)
            .unwrap();
        prev = value;
    }

    written_bits
}

#[inline]
fn i64_to_nat(value: i64) -> u64 {
    if value >= 0 {
        (value as u64) << 1
    } else {
        ((-value) as u64) * 2 - 1
    }
}

#[inline]
fn nat_to_i64(value: u64) -> i64 {
    if value & 1 == 0 {
        (value >> 1) as i64
    } else {
        -((value >> 1) as i64) - 1
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn nd(data: Vec<u32>, offsets: Vec<usize>) -> NeighborData {
        NeighborData {
            data: data.into_boxed_slice(),
            offsets: offsets.into_boxed_slice(),
        }
    }

    fn collect_all<N: Neighbors>(n: &N) -> Vec<u32> {
        let mut out = Vec::new();
        for node_id in 0..n.n_nodes() {
            out.extend(n.iter_node(node_id));
        }
        out
    }

    fn collect_node<N: Neighbors>(n: &N, node_id: usize) -> Vec<u32> {
        n.iter_node(node_id).collect()
    }

    fn expected_concat_segments(data: &[u32], offsets: &[usize]) -> Vec<u32> {
        let mut out = Vec::new();
        if offsets.len() < 2 {
            return out;
        }
        for w in offsets.windows(2) {
            out.extend_from_slice(&data[w[0]..w[1]]);
        }
        out
    }

    fn assert_neighbor_impl_matches_plain_flat<N>(neighbors: N, data: &[u32], offsets: &[usize])
    where
        N: Neighbors,
    {
        let expected = expected_concat_segments(data, offsets);

        assert_eq!(neighbors.len(), expected.len());
        assert_eq!(collect_all(&neighbors), expected);
        assert_eq!(neighbors.n_nodes(), offsets.len().saturating_sub(1));
    }

    fn assert_neighbor_impl_matches_plain_by_segments<N>(
        neighbors: N,
        data: &[u32],
        offsets: &[usize],
    ) where
        N: Neighbors,
    {
        let expected = expected_concat_segments(data, offsets);
        assert_eq!(neighbors.len(), expected.len());

        if offsets.len() < 2 {
            assert!(collect_all(&neighbors).is_empty());
            return;
        }

        for (node_id, w) in offsets.windows(2).enumerate() {
            let start = w[0];
            let end = w[1];
            assert_eq!(
                collect_node(&neighbors, node_id),
                data[start..end].to_vec(),
                "segment mismatch for node {node_id}"
            );
        }
    }

    #[test]
    fn plain_neighbors_full_and_ranges() {
        let raw = nd(vec![1, 3, 7, 2, 4, 9], vec![0, 3, 6]);
        let plain = PlainNeighbors::from(raw.clone());

        assert_eq!(plain.len(), 6);
        assert_eq!(collect_all(&plain), vec![1, 3, 7, 2, 4, 9]);
        assert_eq!(collect_node(&plain, 0), vec![1, 3, 7]);
        assert_eq!(collect_node(&plain, 1), vec![2, 4, 9]);
        assert_eq!(
            plain.byte_size(),
            6 * std::mem::size_of::<u32>() + 3 * std::mem::size_of::<usize>()
        );
    }

    #[test]
    fn elias_fano_offsets_roundtrip() {
        let raw = vec![0usize, 3, 7, 7, 10, 15].into_boxed_slice();
        let ef = EliasFanoOffsets::from(raw.clone());

        assert_eq!(ef.len(), raw.len());
        for i in 0..raw.len() {
            assert_eq!(ef.get(i), raw[i], "offset mismatch at index {i}");
        }
        assert!(ef.byte_size() > 0 || ef.len() == 0);
    }

    #[test]
    fn bitpacked_neighbors_match_plain_single_segment() {
        let raw = nd(vec![0, 1, 3, 7, 8, 15, 31], vec![0, 7]);
        let bp = BitPackedNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_flat(bp, &raw.data, &raw.offsets);
    }

    #[test]
    fn bitpacked_neighbors_match_plain_multiple_segments() {
        let raw = nd(vec![1, 4, 9, 2, 3, 10, 11, 100], vec![0, 3, 3, 7, 8]);
        let bp = BitPackedNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_flat(bp, &raw.data, &raw.offsets);
    }

    #[test]
    fn elias_fano_neighbors_match_plain_single_segment() {
        let raw = nd(vec![2, 5, 9, 14, 20], vec![0, 5]);
        let ef = EliasFanoNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(ef, &raw.data, &raw.offsets);
    }

    #[test]
    fn elias_fano_neighbors_match_plain_multiple_segments() {
        let raw = nd(vec![1, 4, 8, 2, 6, 7, 10, 3, 12], vec![0, 3, 7, 9]);
        let ef = EliasFanoNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(ef, &raw.data, &raw.offsets);
    }

    #[test]
    fn elias_fano_neighbors_with_empty_segments() {
        let raw = nd(vec![1, 2, 10, 20, 21], vec![0, 2, 2, 2, 5]);
        let ef = EliasFanoNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(ef, &raw.data, &raw.offsets);
    }

    #[test]
    fn stream_vbyte_neighbors_match_plain_single_segment() {
        let raw = nd(vec![1, 3, 7, 15, 31], vec![0, 5]);
        let svb = StreamVByteNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(svb, &raw.data, &raw.offsets);
    }

    #[test]
    fn stream_vbyte_neighbors_match_plain_multiple_segments() {
        let raw = nd(vec![2, 4, 8, 9, 3, 5, 11, 100, 101], vec![0, 4, 7, 9]);
        let svb = StreamVByteNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(svb, &raw.data, &raw.offsets);
    }

    #[test]
    fn stream_vbyte_neighbors_with_empty_segments() {
        let raw = nd(vec![1, 5, 9, 20], vec![0, 0, 2, 2, 4]);
        let svb = StreamVByteNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(svb, &raw.data, &raw.offsets);
    }

    #[test]
    fn zeta_neighbors_match_plain_single_segment() {
        let raw = nd(vec![1, 3, 7, 15, 31], vec![0, 5]);
        let zeta = ZetaNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(zeta, &raw.data, &raw.offsets);
    }

    #[test]
    fn zeta_neighbors_match_plain_multiple_segments() {
        let raw = nd(vec![2, 4, 8, 9, 3, 5, 11, 100, 101], vec![0, 4, 7, 9]);
        let zeta = ZetaNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(zeta, &raw.data, &raw.offsets);
    }

    #[test]
    fn zeta_neighbors_with_empty_segments() {
        let raw = nd(vec![1, 5, 9, 20], vec![0, 0, 2, 2, 4]);
        let zeta = ZetaNeighbors::from(raw.clone());

        assert_neighbor_impl_matches_plain_by_segments(zeta, &raw.data, &raw.offsets);
    }

    #[test]
    fn zeta_neighbors_match_plain_for_codec_k_range() {
        let raw = nd(
            vec![1, 3, 7, 15, 31, 2, 4, 8, 9, 20, 21, 22],
            vec![0, 5, 9, 9, 12],
        );

        for codec_k in 2..=8 {
            let zeta = ZetaNeighbors::compress_with_k(&raw, codec_k);
            assert_neighbor_impl_matches_plain_by_segments(zeta, &raw.data, &raw.offsets);
        }
    }

    #[test]
    fn empty_neighbors_are_supported() {
        let raw = nd(vec![], vec![0]);

        let plain = PlainNeighbors::from(raw.clone());
        let bp = BitPackedNeighbors::from(raw.clone());
        let ef = EliasFanoNeighbors::from(raw.clone());
        let zeta = ZetaNeighbors::from(raw.clone());
        let svb = StreamVByteNeighbors::from(raw.clone());

        assert_eq!(plain.len(), 0);
        assert_eq!(bp.len(), 0);
        assert_eq!(ef.len(), 0);
        assert_eq!(zeta.len(), 0);
        assert_eq!(svb.len(), 0);

        assert!(collect_all(&plain).is_empty());
        assert!(collect_all(&bp).is_empty());
        assert!(collect_all(&ef).is_empty());
        assert!(collect_all(&zeta).is_empty());
        assert!(collect_all(&svb).is_empty());
    }

    #[test]
    fn default_stream_vbyte_is_empty() {
        let svb = StreamVByteNeighbors::default();
        assert_eq!(svb.len(), 0);
        assert!(collect_all(&svb).is_empty());
    }

    #[test]
    fn byte_size_is_nonzero_for_nonempty_structures() {
        let raw = nd(vec![1, 2, 3, 8, 13, 21], vec![0, 3, 6]);

        let plain = PlainNeighbors::from(raw.clone());
        let bp = BitPackedNeighbors::from(raw.clone());
        let ef = EliasFanoNeighbors::from(raw.clone());
        let zeta = ZetaNeighbors::from(raw.clone());
        let svb = StreamVByteNeighbors::from(raw.clone());

        assert!(plain.byte_size() > 0);
        assert!(bp.byte_size() > 0);
        assert!(ef.byte_size() > 0);
        assert!(zeta.byte_size() > 0);
        assert!(svb.byte_size() > 0);
    }
}

# Graph-Compressed HNSW Experiments

## Table of Contents

- [Reproducing Our Experiments](#reproducing-our-experiments)
  - [Compilation](#compilation)
  - [Downloading the Datasets](#downloading-the-datasets)
  - [Prerequisites](#prerequisites)
  - [Quick Reproduction Steps](#quick-reproduction-steps)
  - [Understanding the Binaries](#understanding-the-binaries)

---

## Reproducing Our Experiments

This package contains the code and scripts to reproduce the experimental results from our paper.

Experiments evaluate runtime graph compression techniques applied to HNSW search across dense and sparse datasets. Each experiment runs the same graph index under different search-time compression modes (`none`, `bit-packed`, `elias-fano`, `zeta`, `stream-v-byte`), with and without EGB node permutation.

All workflows are driven by the Python script `scripts/run_experiments.py` and configured via TOML files under `experiments/cikm2026/`.

### Compilation

Reproducibility is guaranteed by `Cargo.lock`, which pins the exact commit of every direct and transitive dependency. The source code of all Rust dependencies is vendored in the `vendor/` directory and `.cargo/config.toml` points Cargo to it, so no Internet access is required to compile (only the Rust toolchain itself must be installed).

To compile the binaries, install the Rust nightly toolchain (see [Prerequisites](#prerequisites)) and run:

```bash
RUSTFLAGS="-C target-cpu=native" cargo build --release --features cli
```

This produces `hnsw_build`, `hnsw_compress_search`, and `hnsw_egb_permutation` under `target/release/`.

> **Note:** `run_experiments.py` automatically recompiles the project at the start of every run using the same command. Pre-compiling manually is still recommended to catch build errors early and to avoid compilation overhead during the timed experiment.

---

### Downloading the Datasets

All datasets used in the paper, except the private dataset provided by eBay, are available on Hugging Face: [https://huggingface.co/collections/tuskanny/graph-compression-datasets](https://huggingface.co/collections/tuskanny/graph-compression-datasets)

#### Dense Datasets

**SIFT1M** — 1M vectors, 128 dimensions, Euclidean distance

- `dataset.npy` — document vectors
- `queries.npy` — query vectors
- `groundtruth.npy` — ground truth (numpy format)

**Snowflake** — 8.8M vectors, 1024 dimensions, dot product similarity, with Product Quantization

- `documents.npy` — document vectors
- `queries.npy` — query vectors
- `groundtruth.tsv` — ground truth (TSV format)

#### Sparse Dataset

**MS MARCO CoCondenser** — 8.8M sparse vectors, dot product similarity

- `documents.bin` — sparse document vectors (use this to build the index)
- `queries.bin` — sparse query vectors
- `groundtruth.tsv` — ground truth for recall evaluation (TSV format)
- `doc_ids.npy` — document identifiers
- `queries_ids.npy` — query identifiers

---

### Prerequisites

Before reproducing the experiments you need:

**Rust toolchain** (required to compile the binaries):

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

The repository includes a `rust-toolchain.toml` file that pins the nightly toolchain (`nightly-2026-07-20`) used for the paper's experiments. `cargo` will automatically install and use the correct toolchain on the first build — no manual `rustup install nightly` step is needed.

**Python dependencies**

```bash
pip install -r scripts/requirements.txt
```

This installs: `ir_measures`, `kannolo`, `numpy`, `pandas`, `psutil`, `termcolor`, and `toml`.

> **Note:** The runner pins execution to a single physical CPU and local memory node via `numactl` (configured in `[settings].NUMA` in each TOML). Make sure `numactl` is available on your system. If your machine is not NUMA, comment out that line in the TOML. The runner also checks that CPUs are set to the `performance` frequency governor via `cpufreq-info`. This tool must be installed on your machine: if it is not available, execution fails. If `cpufreq-info` is installed but the governor is not set to `performance`, a warning is printed but execution continues.

---

### Quick Reproduction Steps

1. **Compile the binaries**:

```bash
RUSTFLAGS="-C target-cpu=native" cargo build --release --features cli
```

This produces the following binaries under `target/release/`:
- `hnsw_build` — builds and stores the HNSW graph index
- `hnsw_egb_permutation` — precomputes an EGB node permutation on an existing index
- `hnsw_compress_search` — searches the index with runtime graph compression support

2. **Update dataset and index paths in the TOML files:**

Edit the `[folder]` section in each TOML under `experiments/cikm2026/` to point to your local data and index directories:

```toml
[folder]
data =  "/path/to/dataset"
index = "/path/to/index_output"
```

3. **Build indexes, compute permutations, and run the experiments:**

The shipped TOML files have `build = true` and `permutation = true` set permanently. A single invocation builds the index, precomputes the EGB permutation, and runs all query configurations in sequence. Set `build = false` and/or `permutation = false` only when the index or permutation already exist on disk and you want to skip rebuilding them.

The index parameters used per dataset are:

| Dataset | `dataset-type` | `encoder` | `value-type` | M | ef-construction | distance |
|---------|---------------|-----------|--------------|---|-----------------|----------|
| SIFT1M | dense | plain | f16 | 32 | 200 | euclidean |
| Snowflake | dense | pq | f16 | 32 | 500 | dotproduct |
| CoCondenser | sparse | dotvbyte | fixedu8 | 32 | 2000 | dotproduct |

Snowflake uses a PQ encoder with `pq-subspaces = 128` (see `[pq_parameters]` in its TOML). The search is a two-stage pipeline: the HNSW graph (built over PQ-encoded vectors) retrieves `k_candidates` approximate neighbours, which are then rescored using the original full-precision vectors to return the final top `k`.
This simulates the practical scenario where compressed in-memory vectors reduce the memory footprint of the graph, making edge storage the dominant cost, while full-precision vectors are loaded from disk only at reranking time.
CoCondenser additionally requires `component-type = u16`.

The EGB permutation is saved alongside the index as `<index_file>_permutation.npy`. It is required for query configurations with `permute = true` (used by `stream-v-byte` and `zeta` compression modes). The index filename is derived automatically from the TOML parameters (dataset name, M, ef-construction, etc).

4. **Run the experiments:**

With the index and the permutation in place, run each TOML configuration:

```bash
# Dense SIFT1M
python3 scripts/run_experiments.py --exp experiments/cikm2026/dense_sift1m.toml

# Dense Snowflake (PQ index)
python3 scripts/run_experiments.py --exp experiments/cikm2026/dense_snowflake.toml

# Sparse MS MARCO CoCondenser
python3 scripts/run_experiments.py --exp experiments/cikm2026/sparse_cocondenser.toml
```

Each run creates a timestamped folder under `[folder.experiment]` (default: `.`) containing:
- `report.tsv` — query time (µs), bits/edge, recall, memory usage, and building time per configuration
- `experiment_config.toml` — full configuration snapshot
- `machine.output` — hardware info (hostname, CPU usage, memory, NUMA topology, `lscpu` output)
- `git.output` — static note indicating the package was distributed as a zip (no git metadata)
- `compiler.output` — full output of the Rust compilation step
- `building.output` — output of `hnsw_build` (index construction log)
- `permutation.output` — output of `hnsw_egb_permutation` (EGB permutation log)
- `log_<subsection>` — per-configuration log from `hnsw_compress_search`, including accuracy
- `results_<subsection>` — per-query result file (TSV: `query_id`, `doc_id`, `rank`, `score`)

#### Compression modes tested

Each TOML file includes query subsections for three recall targets (0.90, 0.94, 0.98) × all compression modes:

| Mode | EGB permutation | Notes |
|------|-----------------|-------|
| `none` | no | Uncompressed baseline |
| `bit-packed` | no | Bit-packing of adjacency lists |
| `elias-fano` | no | Elias-Fano coding |
| `stream-v-byte` | yes | StreamVByte |
| `zeta` | yes | Zeta coding; requires `--zeta-k` |

---

### Understanding the Binaries

#### `hnsw_build`

Builds a new HNSW index from a dataset file.

```bash
./target/release/hnsw_build \
  --data-file <dataset> \
  --output-file <index> \
  --dataset-type <dense|sparse> \
  --value-type <f16|f32|fixedu8|fixedu16> \
  --encoder <plain|pq|dotvbyte> \
  --m <M> \
  --ef-construction <EFC> \
  --distance <euclidean|dotproduct> \
  [--pq-subspaces <M>] \
  [--component-type <u16|u32>]
```

Key notes:
- `pq` encoder is dense-only; `dotvbyte` is sparse-only.
- `--pq-subspaces` must divide the vector dimensionality and must be one of 4, 8, 16, 32, 48, 64, 96, 128, 192.
- For sparse datasets, pass `--component-type <u16|u32>`.

#### `hnsw_egb_permutation`

Precomputes an EGB node permutation on an existing index and saves it to `--output-file`. Required before running query configurations with `permute = true`.

```bash
./target/release/hnsw_egb_permutation \
  --index-file <index> \
  --output-file <index>_permutation.npy \
  --dataset-type <dense|sparse> \
  --value-type <f16|f32|...> \
  --encoder <plain|pq|dotvbyte> \
  --distance <euclidean|dotproduct> \
  [--pq-subspaces <M>] \
  [--component-type <u16|u32>]
```

When using `run_experiments.py`, the output file is automatically set to `<index_file>_permutation.npy`.

Key notes:
- `--pq-subspaces` is required when `--encoder pq`; must match the value used at build time.
- `--component-type` is required for sparse datasets.

#### `hnsw_compress_search`

Searches an HNSW index with configurable runtime graph compression. Supports all compression modes listed above.

```bash
./target/release/hnsw_compress_search \
  --index-file <index> \
  --query-file <queries> \
  --dataset-type <dense|sparse> \
  --value-type <f16|f32|...> \
  --encoder <plain|pq|dotvbyte> \
  --distance <euclidean|dotproduct> \
  --k 10 \
  --ef-search <EF> \
  --early-termination <none|distance-adaptive> \
  --lambda <lambda> \
  --compression <none|bit-packed|elias-fano|zeta|stream-v-byte> \
  [--permutation-file <index>_permutation.npy] \
  [--zeta-k <k>] \
  [--pq-subspaces <M>] \
  [--component-type <u16|u32>] \
  [--num-runs <N>] \
  [--rerank-dataset <f32_dataset>] \
  [--k-candidates <N>] \
  --output-path <results.tsv>
```

Key notes:
- `--compression none` is the uncompressed baseline.
- `--permutation-file` loads a precomputed EGB permutation; run `hnsw_egb_permutation` first. Required for `zeta` and `stream-v-byte`.
- `--pq-subspaces <M>` is required for PQ-encoded indexes (e.g. Snowflake uses `--pq-subspaces 128`).
- `--component-type` is required for sparse datasets (e.g. `--component-type u16` for CoCondenser).
- `--num-runs` repeats the search N times for stable timing measurements (default: 1).
- `--rerank-dataset` enables full-precision reranking of PQ results; `--k-candidates` sets how many candidates to retrieve before reranking (default: k × 10). If omitted, the search returns PQ-distance results directly without the reranking step.
- `--early-termination distance-adaptive` enables early exit during graph traversal; `--lambda` controls its aggressiveness. Not used for PQ-encoded indexes.

#### Output format

All search binaries write results as a four-column TSV:

```
query_id  doc_id  rank  score
```

Row ordering is by query then by rank. Recall is computed against the groundtruth file by `run_experiments.py` automatically.

The `report.tsv` produced by the runner has the following columns:

```
Subsection  Query Time (microsecs)  Bits/Edge  Accuracy  Memory Usage (Bytes)  Building Time (secs)
```
